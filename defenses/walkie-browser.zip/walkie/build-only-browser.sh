# Install a subset of the packages listed in
# https://gitweb.torproject.org/builders/tor-browser-bundle.git/tree/gitian/descriptors/linux/gitian-firefox.yml#l8
# Mostly, we don't need `libiw-dev` or `faketime`, but we *do* need `pkg-config`.

sudo torsocks apt-get install \
    --no-install-suggests --no-install-recommends \
    zip \
    unzip \
    libglib2.0-dev \
    libgtk2.0-dev \
    libdbus-1-dev \
    libdbus-glib-1-dev \
    yasm \
    libasound2-dev \
    libcurl4-openssl-dev \
    libxt-dev \
    mesa-common-dev \
    autoconf \
    autoconf2.13 \
    libtool \
    hardening-wrapper \
    libgstreamer-plugins-base0.10-dev \
    pkg-config \
    g++ \
    libpulse-dev

# Generate the configure scripts:
make $CONFIGURE_ARGS -f client.mk configure CONFIGURE_ARGS="--with-tor-browser-version=4.5a4 --enable-update-channel=alpha"

# And... compile:
make $MAKEOPTS -f client.mk build
make -C obj-* package INNER_MAKE_PACKAGE=true

# Point the INSTDIR at an existing TBB directory:
export INSTDIR="$HOME/tbb/test/tor-browser_en-US"

# Move the compiled firefox on top of the old TBB browser dir:
cp -a obj-*/dist/firefox/* $INSTDIR/Browser/

# If you want a smaller binary to copy into a vm/other machine for tests:
strip --strip-all $INSTDIR/Browser/*
rm -f $INSTDIR/Browser/firefox-bin

